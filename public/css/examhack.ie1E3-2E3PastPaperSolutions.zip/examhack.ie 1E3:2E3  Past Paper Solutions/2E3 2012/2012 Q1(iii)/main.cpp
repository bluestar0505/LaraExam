#include <iostream>
using namespace std;


int countOnes(char c)
{
    int count = 0;
    
    while (c != 0) 
    {
        if (c & 0x1 == 1) 
            count++; /* if the rightmost bit of c is 1, then count++ */
        c = c / 2;
    }
    
    return count;
}


int main(int argc, char **argv)
{
	cout << countOnes(65);
	return 0;
}
