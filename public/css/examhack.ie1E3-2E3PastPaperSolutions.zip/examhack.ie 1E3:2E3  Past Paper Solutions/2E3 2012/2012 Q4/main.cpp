#include <iostream>
#include <string>
#include "LinkedList.h"
using namespace std;

int main()
{
    
    TE3Makrs l;
    l.AddMark(10);
    l.AddMark(20);
    l.AddMark(30);
    l.AddMark(40);

    cout << "Highest " << l.getHighest() << "\n";
    cout << "Lowest " << l.getLowest() << "\n";
    cout << "Average " << l.calculateAverage() << "\n";
    l.RemoveMark(10);
    
    return 0;
}