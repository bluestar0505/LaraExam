#include <iostream>
#include <string>
using namespace std;

class TE3Makrs{
    // Struct inside the class LinkedList
    // This is one node which is not needed by the caller. It is just
    // for internal work.
    struct MarkNode {
        double mark;
        MarkNode *next;
    };

// public member
public:
    // constructor
    TE3Makrs(){
        head = NULL; // set head to NULL
    }


    ~TE3Makrs(){
         MarkNode* temp = head;
         MarkNode* next;
        while (temp !=NULL)
        {
            next = temp-> next; 
            delete temp; 
            temp = next; 

        }//end of while loo // set head to NULL
    }
    
    // This prepends a new value at the beginning of the list
    void AddMark(double val){
        MarkNode *n = new MarkNode();   // create new Node
        n->mark = val;             // set value
        n->next = NULL;         // make the node point to the next node.
                                //  If the list is empty, this is NULL, so the end of the list --> OK
        
        
        if (head == NULL)
        {
            head = n;
            return;
        }
        
        MarkNode* temp = head;
        MarkNode* prev = NULL;
        
        while (temp != NULL && temp->mark <= val)
        {
            prev = temp;
            temp = temp->next;
        }
        
        if (temp == NULL)
        {
            prev->next = n;
        }
        else if (temp->mark > val)
        {
            n->next = temp;
            prev->next = n;
        }
        
        
    }

    double getHighest()
    {
        MarkNode* temp = head;
        
        if (head == NULL)
        {
            return 0;
        }
        while (temp->next != NULL)
        {
            //cout << temp->x << "\n";
            temp = temp->next;
        }

        return temp->mark;    
    }
    
    double getLowest()
    {
        MarkNode* temp = head;
        
        if (head == NULL)
        {
            return 0;
        }
        
        return temp->mark;    
    }
    
    
    void RemoveMark(double value)
    {
           // Store head node
        MarkNode* temp = head;
        MarkNode* prev = NULL;
     
        // If head node itself holds the value to be deleted
        if (temp != NULL && temp->mark == value)
        {
            head = temp->next;   // Changed head
            delete temp;               // free old head
            return;
        }
     
        // Search for the value to be deleted, keep track of the
        // previous node as we need to change 'prev->next'
        while (temp != NULL && temp->mark != value)
        {
            prev = temp;
            temp = temp->next;
        }
     
        // If value was not present in linked list
        if (temp == NULL) return;
     
        // Unlink the node from linked list
        prev->next = temp->next;
     
        delete temp;  // Free memory
        return;
    }
    
    double calculateAverage()
    {
        int count = 0;
        int sum = 0;
        
        MarkNode* temp = head;
        
        while (temp != NULL)
        {
            count++;
            sum += temp->mark;
            temp = temp->next;
        }
        
        return sum / count;
    }
    
    void print()
    {
        
        MarkNode* temp = head;
        
        while (temp != NULL)
        {
            cout << temp->mark << "\n";
            temp = temp->next;
        }                

    }

// private member
private:
    MarkNode *head; // this is the private member variable. It is just a pointer to the first Node
};