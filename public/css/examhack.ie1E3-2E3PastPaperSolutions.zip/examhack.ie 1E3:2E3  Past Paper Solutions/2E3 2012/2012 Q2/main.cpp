#include <iostream>
#include <string>
#include <cstring>
using namespace std;


class DiaryEntry
{
public:
    int day;
    int month;
    int year;
    
    char* entry;
    
    DiaryEntry()
    {
        day = 1;
        month = 9;
        year = 2016;
        entry = new char;
        *entry = '\0';
    }
    
    DiaryEntry(char* e, int d, int m, int y)
    {
        day = d;
        month = m;
        year = y;
        entry = new char[strlen(e)];
        strcpy(entry, e);
    }

    DiaryEntry(const DiaryEntry& d)
    {
        day = d.day;
        month = d.month;
        year = d.year;
        entry = new char[strlen(d.entry)];
        strcpy(entry, d.entry);
    }   
    
    void operator = (DiaryEntry& rhs)
    {
        day = rhs.day;
        month = rhs.month;
        year = rhs.year;
        entry = new char[strlen(rhs.entry)];
        strcpy(entry, rhs.entry);
    }
    
    

    int countWords()
    {
        if (entry == NULL)
            return 0;  // let the requirements define this...

       bool inSpaces = true;
       int numWords = 0;

       while (*entry != NULL)
       {
          if (std::isspace(*entry))
          {
             inSpaces = true;
          }
          else if (inSpaces)
          {
             numWords++;
             inSpaces = false;
          }

          ++entry;
       }

       return numWords;
    }
};

int main(int argc, char **argv)
{

    // default cosntructor, this diearly gets created with current date and blank content
    DiaryEntry d;
    // parametric, thsi creates diary with given date and content
    DiaryEntry d1("First day", 19, 9, 1988);
    // copy cosntructor, if we want to create the same content aspreviously created one
    DiaryEntry d2(d1);
    
    // assignment operator
    // creates default, empty one
    DiaryEntry d4;
    // assigns from existing
    d4 = d1;
    
    // count words
    cout << d4.countWords();

	return 0;
}
