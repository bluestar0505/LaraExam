#include <iostream>

unsigned int factorial(unsigned int n) {
  if (n == 1) {
    return 1;
  } else {
    return factorial(n-1) * n;
  }
}

double sum(unsigned int n) {
  double result;
  for(unsigned int i = 1; i <= n; ++i) {
    double val = i * 1.0 / factorial(i);
    result += val;
  }
  return result;
}

int main() {
  //Inifinite sequence of X marks, because value takes only {1, 10} values => stop condition never happens
  //  int value = 1;
  //  do {
  //    std::cout << "X";
  //    value = 10;
  //  } while(!(value == 10) || !(value == 20));

  unsigned int n = 0;
  std::cout << "Please, enter n: ";
  std::cin >> n;
  std::cout << sum(n) << std::endl;
}
