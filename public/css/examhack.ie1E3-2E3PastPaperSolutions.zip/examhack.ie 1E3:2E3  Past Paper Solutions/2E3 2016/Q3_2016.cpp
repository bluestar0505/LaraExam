#include <iostream>

class Complex {
public:
  Complex() : values(NULL) {
    init(0.0, 0.0);
  }

  Complex(double re, double im) : values(NULL) {
    init(re, im);
  }

  Complex(const Complex& other) : values(NULL) {
    (*this) = other;
  }

  ~Complex() {
    clear();
  }

  Complex operator+(const Complex& rhs) const {
    return Complex(re() + rhs.re(), im() + rhs.im());
  }

  void operator=(const Complex& rhs) {
    init(rhs.re(), rhs.im());
  }

  void print() {
    std::cout << re() << " + " << im() << "i" << std::endl;
  }

private:
  double re() const {
    return values[0];
  }
  double im() const {
    return values[1];
  }

  void clear() {
    if (values != NULL) {
      delete[] values;
      values = NULL;
    }
  }

  void init(double re, double im) {
    clear();
    values = new double[2];
    values[0] = re;
    values[1] = im;
  }

  double* values;
};

int main() {
  /* Empty number test */ {
    Complex num;
    num.print();
  }

  /* Non-empty number test */ {
    Complex num(2,3);
    num.print();
  }

  /* 2 empty number test */ {
    Complex num;
    Complex num2(num);

    num.print();
    num2.print();
  }

  /* 2 empty number test */ {
    Complex num;
    Complex num2 = num;

    num.print();
    num2.print();
  }

  /* 2 Non-empty number test */ {
    Complex num(2,3);
    Complex num2(num);

    num.print();
    num2.print();
  }

  /* 2 Non-empty number test */ {
    Complex num(2,3);
    Complex num2 = num;

    num.print();
    num2.print();
  }

  /* Empty & Non-empty number test */ {
    Complex num(2,3);
    Complex num2;
    num = num2;

    num.print();
    num2.print();
  }

  /* Empty & Non-empty number test */ {
    Complex num(2,3);
    Complex num2;
    num2 = num;

    num.print();
    num2.print();
  }

  /* Empty & Non-empty number test */ {
    Complex num(2,3);
    Complex num2;
    Complex num3 = num2 + num;

    num.print();
    num2.print();
    num3.print();
  }

  /* Empty & Non-empty number test */ {
    Complex num(2,3);
    Complex num2;
    Complex num3 = num + num2;

    num.print();
    num2.print();
    num3.print();
  }

  /* 2 Non-empty number test */ {
    Complex num(2,3);
    Complex num2(2,5);
    Complex num3 = num + num2;

    num.print();
    num2.print();
    num3.print();
  }

  return 0;
}
