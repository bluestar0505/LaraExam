#include <iostream>
#include <string>

class Number {
public:
  int no;
  Number* left;
  Number* right;
};

class TreeOfNumbers {
public:
  TreeOfNumbers() : root(NULL), count(0) {}

  ~TreeOfNumbers() {
    removeNode(root);
  }

  bool addNumber(const int n) {
    Number*& pNumber = search(root, n);
    if (pNumber == NULL) {
      pNumber = new Number;
      pNumber->no = n;
      pNumber->left = NULL;
      pNumber->right = NULL;
      count += 1;
      return true;
    } else {
      return false;
    }
  }

  int size() const {
    return count;
  }

  int minValue() const {
    Number* pMinNode = root;
    if (pMinNode == NULL) {
      throw "Tree is empty";
    }
    while(pMinNode->left) {
      pMinNode = pMinNode->left;
    }
    return pMinNode->no;
  }

  void print() const {
    std::cout << std::string(80, '-') << std::endl;
    printNode(root);
    std::cout << std::endl;
  }

private:
  Number*& search(Number*& pNode, const int n) {
    if ((pNode == NULL) || (pNode->no == n)) {
      return pNode;
    } else if (pNode->no < n) {
      return search(pNode->right, n);
    } else {
      return search(pNode->left, n);
    }
  }

  void removeNode(Number*& pNode) {
    if (pNode == NULL) {
      return;
    }
    removeNode(pNode->left);
    removeNode(pNode->right);
    delete pNode;
    pNode = NULL;
  }

  void printNode(Number* pNode) const {
    if (pNode == NULL) {
      return;
    }
    printNode(pNode->left);
    std::cout << pNode->no << " ";
    printNode(pNode->right);
  }

  Number* root;
  unsigned int count;
};

#define TEST_EXCEPT(expression, expected_result) \
                                                 \
{                                                \
    bool result = false;                         \
    try {                                        \
      (expression);                              \
    } catch (const char* msg) {                  \
      result = true;                             \
    }                                            \
    if (result != expected_result) {             \
      throw "Test failed.";                      \
    }                                            \
}

#define TEST(expression)                                           \
  /* To check we've no side effects, run each test twice */        \
  for (unsigned int i = 0; i < 2; ++i) {                           \
    bool result = (expression);                                    \
    if (!result) throw "Test failed.";                             \
  }

#define TEST2(expression)                                           \
  if (!(expression)) throw "Test failed.";


int main() {
  TreeOfNumbers tree;
  TEST_EXCEPT(tree.minValue(), true);
  TEST(tree.size() == 0);
  tree.print();

  TEST2(tree.addNumber(10) == true);
  TEST2(tree.addNumber(10) == false);
  TEST(tree.minValue() == 10);
  TEST(tree.size() == 1);
  tree.print();

  TEST2(tree.addNumber(32) == true);
  TEST2(tree.addNumber(32) == false);
  TEST(tree.minValue() == 10);
  TEST(tree.size() == 2);
  tree.print();

  TEST2(tree.addNumber(423) == true);
  TEST2(tree.addNumber(423) == false);
  TEST(tree.minValue() == 10);
  TEST(tree.size() == 3);
  tree.print();

  TEST2(tree.addNumber(127) == true);
  TEST2(tree.addNumber(127) == false);
  TEST(tree.minValue() == 10);
  TEST(tree.size() == 4);
  tree.print();

  TEST2(tree.addNumber(7) == true);
  TEST2(tree.addNumber(7) == false);
  TEST(tree.minValue() == 7);
  TEST(tree.size() == 5);
  tree.print();

  TEST2(tree.addNumber(9) == true);
  TEST2(tree.addNumber(9) == false);
  TEST(tree.minValue() == 7);
  TEST(tree.size() == 6);
  tree.print();

  TEST2(tree.addNumber(3) == true);
  TEST2(tree.addNumber(3) == false);
  TEST(tree.minValue() == 3);
  TEST(tree.size() == 7);
  tree.print();

  return 0;
}
