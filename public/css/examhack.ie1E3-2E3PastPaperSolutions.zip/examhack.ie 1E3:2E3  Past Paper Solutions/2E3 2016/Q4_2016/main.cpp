#include "LinkedList.h"

#define TEST_EXCEPT(expression, expected_result) \
                                                 \
{                                                \
    bool result = false;                         \
    try {                                        \
      (expression);                              \
    } catch (const char* msg) {                  \
      result = true;                             \
    }                                            \
    if (result != expected_result) {             \
      throw "Test failed.";                      \
    }                                            \
}

#define TEST(expression)                                           \
  /* To check we've no side effects, run each test twice */        \
  for (unsigned int i = 0; i < 2; ++i) {                           \
    bool result = (expression);                                    \
    if (!result) throw "Test failed.";                             \
  }


int main() {
  LinkedList list;
  TEST(list.sum() == 0);
  TEST(list.size() == 0);
  list.remove(2);

  list.add(2);
  TEST(list.sum() == 2);
  TEST(list.size() == 1);

  list.remove(2);
  TEST(list.sum() == 0);
  TEST(list.size() == 0);

  list.add(2);
  TEST(list.size() == 1);
  list.add(2);
  TEST(list.size() == 2);
  TEST(list.sum() == 4);


  list.remove(2);
  TEST(list.sum() == 0);
  TEST(list.size() == 0);

  list.add(3);
  TEST(list.size() == 1);
  list.add(2);
  TEST(list.size() == 2);
  list.add(7);
  TEST(list.size() == 3);
  list.add(12);
  TEST(list.size() == 4);
  list.add(7);
  TEST(list.size() == 5);
  TEST(list.sum() == (2 + 3 + 7 + 12 + 7));

  list.remove(7);
  TEST(list.size() == 3);
  TEST(list.sum() == (2 + 3 + 12));

  return 0;
}
