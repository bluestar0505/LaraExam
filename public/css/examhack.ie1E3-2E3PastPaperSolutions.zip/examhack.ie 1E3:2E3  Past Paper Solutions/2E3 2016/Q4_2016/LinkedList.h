#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#define NULL 0

class DoubleList {
public:
  double data;
  DoubleList* pNext;
};

class LinkedList {
public:

  LinkedList() : pHead(NULL) {}

  ~LinkedList() {
    while(pHead != NULL) {
      removeItem(pHead);
    }
  }

  void add(double d) {
    DoubleList** ppEnd = &pHead;
    while((*ppEnd) != NULL) {
      ppEnd = &((*ppEnd)->pNext);
    }
    DoubleList*& pEnd = *ppEnd;
    pEnd = new DoubleList;
    pEnd->data = d;
    pEnd->pNext = NULL;
  }

  void remove(double d) {
    DoubleList** ppItem = &pHead;
    while((*ppItem) != NULL) {
      DoubleList*& pItem = *ppItem;
      if (pItem->data == d) {
        removeItem(pItem);
      } else {
        ppItem = &(pItem->pNext);
      }
    }
  }

  int size() const {
    int result = 0;
    DoubleList* pItem = pHead;
    while(pItem != NULL) {
      result += 1;
      pItem = pItem->pNext;
    }
    return result;
  }

  double sum() const {
    double result = 0;
    DoubleList* pItem = pHead;
    while(pItem != NULL) {
      result += pItem->data;
      pItem = pItem->pNext;
    }
    return result;
  }

private:
  void removeItem(DoubleList*& pItem) {
    DoubleList* pTemp = pItem;
    pItem = pItem->pNext;
    delete pTemp;
    pTemp = NULL;
  }

  DoubleList* pHead;
};

#endif // LINKEDLIST_H
