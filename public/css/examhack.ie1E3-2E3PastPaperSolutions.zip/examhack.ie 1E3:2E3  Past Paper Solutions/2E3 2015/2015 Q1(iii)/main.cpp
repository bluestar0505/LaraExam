#include <iostream>
#include <string>
using namespace std;


void displayBinaryRepresentation(int n)
{
    std::string r;
    while(n!=0) {r=(n%2==0 ?"0":"1")+r; n/=2;}

    cout << r;
}


int main(int argc, char **argv)
{
	displayBinaryRepresentation(7);
	return 0;
}
