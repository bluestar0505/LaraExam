#include <iostream>
#include <string>
#include <cstring>
using namespace std;


class Matrix
{
private:
    int mRows, mColumns;
    double* mMatrix;
    
public:
    Matrix(int rows, int columns)
    {
        mRows = rows;
        mColumns = columns;
        mMatrix = new double[rows * columns];
        for (int i = 0; i < mRows * mColumns; i++)
        {
            mMatrix[i] = 0;
        }
    }
    
    Matrix(const Matrix& m)
    {
        this->mColumns = m.mColumns;
        this->mRows = m.mRows;
        this->mMatrix = new double [mColumns * mRows];
        
        for (int i = 0; i < mRows * mColumns; i++)
        {
            mMatrix[i] = m.mMatrix[i];
        }
    }
    
    ~Matrix()
    {
        delete[] mMatrix;
    }
    
    double GetElement(int row, int column)
    {
        if ((row*column) >=0 && ((row*column) < (mRows*mColumns)))
        {
            return mMatrix[row * column];
        }
        return -1;
    }
    
    bool SetElement(int row, int column, double value)
    {
        if ((row*column) >= 0 && ((row*column) < (mRows*mColumns)))
        {
            mMatrix[row * column] = value;
            return true;
        }
        return false;
    }
    
    Matrix operator + (Matrix& rhs)
    {
        Matrix result(*this);
        
        for (int i = 0; i < mRows * mColumns; i++)
        {
            result.mMatrix[i] += rhs.mMatrix[i];
        }
        
        return result;
    }
    
    void operator = (Matrix& rhs)
    {
        this->mColumns = rhs.mColumns;
        this->mRows = rhs.mRows;
        this->mMatrix = new double [mColumns * mRows];
        
        for (int i = 0; i < mRows * mColumns; i++)
        {
            mMatrix[i] = rhs.mMatrix[i];
        }
    }
    
        
};
    

int main(int argc, char **argv)
{

   Matrix m1(2, 2);
   
   Matrix m2(m1);
   m2.SetElement(1, 1, 10) ;
   m2.SetElement(1, 2, 20);
   
   Matrix m3 = m1 + m2;
   Matrix m4(2, 2);
   m4 = m3;

	return 0;
}
