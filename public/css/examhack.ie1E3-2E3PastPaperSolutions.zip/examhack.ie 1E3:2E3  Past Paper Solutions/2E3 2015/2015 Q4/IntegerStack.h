#ifndef INTEGERSTACK_H
#define INTEGERSTACK_H

#include <iostream>
#include "IntegerNode.h"

class IntegerStack {
public:
  IntegerStack() : head(NULL) {}

  ~IntegerStack() {
    IntegerNode* pNode = head;
    while(pNode != NULL) {
      removeNode(pNode);
    }
  }

  void push(const int value) {
    IntegerNode* pTemp = head;
    head = new IntegerNode;
    head->data = value;
    head->next = pTemp;
  }

  int pop() {
    if (head == NULL) {
      throw "Stack is empty.";
    }
    int result = head->data;
    removeNode(head);
    return result;
  }

  void printStack() const {
    IntegerNode* pNode = head;
    std::cout << std::string(80, '-') << std::endl;
    while(pNode != NULL) {
      std::cout << pNode->data << std::endl;
      pNode = pNode->next;
    }
  }

  bool find(const int value) const {
    IntegerNode* pNode = head;
    while(pNode != NULL) {
      if (pNode->data == value) {
        return true;
      }
      pNode = pNode->next;
    }
    return false;
  }

private:
  void removeNode(IntegerNode*& pNode) {
    IntegerNode* pTemp = pNode;
    pNode = pNode->next;
    delete pTemp;
    pTemp = NULL;
  }

  IntegerNode* head;
};

#endif // INTEGERSTACK_H
