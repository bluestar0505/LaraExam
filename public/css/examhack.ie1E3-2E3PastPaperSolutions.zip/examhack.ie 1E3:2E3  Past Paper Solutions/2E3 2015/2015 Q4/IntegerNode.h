#ifndef INTEGERNODE_H
#define INTEGERNODE_H

class IntegerNode {
public:
  int data;
  IntegerNode* next;
};

#endif // INTEGERNODE_H
