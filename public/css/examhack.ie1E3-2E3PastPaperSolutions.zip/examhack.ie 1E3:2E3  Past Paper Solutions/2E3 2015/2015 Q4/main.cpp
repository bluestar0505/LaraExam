#include "IntegerStack.h"

#define TEST_EXCEPT(expression, expected_result) \
                                                 \
{                                                \
    bool result = false;                         \
    try {                                        \
      (expression);                              \
    } catch (const char* msg) {                  \
      result = true;                             \
    }                                            \
    if (result != expected_result) {             \
      throw "Test failed.";                      \
    }                                            \
}

#define TEST(expression)                                           \
  /* To check we've no side effects, run each test twice */        \
  for (unsigned int i = 0; i < 2; ++i) {                           \
    bool result = (expression);                                    \
    if (!result) throw "Test failed.";                             \
  }

#define TEST2(expression)                                           \
  if (!(expression)) throw "Test failed.";                          \

int main() {
  IntegerStack stack;
  stack.printStack();
  TEST_EXCEPT(stack.pop(), true);
  TEST(stack.find(10) == false);

  stack.push(10);
  TEST(stack.find(10) == true);
  TEST2(stack.pop() == 10);

  stack.push(10);
  stack.printStack();
  stack.push(32);
  stack.printStack();
  stack.push(432);
  stack.printStack();
  stack.push(2);
  stack.printStack();
  stack.push(5423);
  stack.printStack();
  TEST(stack.find(2) == true);
  stack.printStack();
  TEST2(stack.pop() == 5423);
  stack.printStack();
  TEST2(stack.pop() == 2);
  stack.printStack();
  TEST2(stack.pop() == 432);
  stack.printStack();
  TEST2(stack.pop() == 32);
  stack.printStack();
  TEST2(stack.pop() == 10);
  stack.printStack();

  return 0;
}
