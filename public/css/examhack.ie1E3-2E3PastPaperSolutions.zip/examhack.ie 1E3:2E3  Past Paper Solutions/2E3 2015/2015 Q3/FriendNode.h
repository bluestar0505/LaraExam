#include <string>
using namespace std;

class FriendNode
{
public:
    
    string fname;
    string lname;
    FriendNode* left;
    FriendNode* right;
    
    bool lessThan(FriendNode f)
    {
        if (lname.compare(f.lname) < 0)
        {
            return true;
        }
        else if (lname.compare(f.lname) > 0)
        {
            return false;
        }
        else
        {
            if (fname.compare(f.fname) <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
    bool isEqual(FriendNode f)
    {
        return ((fname.compare(f.fname) && lname.compare(f.lname)) == 0);
    }
};