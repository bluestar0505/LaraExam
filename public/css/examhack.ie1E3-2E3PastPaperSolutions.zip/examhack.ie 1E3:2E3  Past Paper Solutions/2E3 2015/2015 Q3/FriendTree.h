#include "FriendNode.h"
class FriendTree
{
    public : FriendNode* root;
    
    public: FriendTree()
    {
        root = NULL;
    }
    
    FriendNode* insert(FriendNode* node, string fname, string lname)
    {
      FriendNode* n = new FriendNode();
        n->fname = fname;
              n->lname = lname;
              n->left = NULL;
              n->right = NULL;

        /* If the tree is empty, return a new node */
        if (node == NULL) 
        {
              
            
              node = n;
              
              return n;
        }
            
    
        /* Otherwise, recur down the tree */
        if (n->lessThan(*node))
            node->left  = insert(node->left, fname, lname);
        else 
            node->right = insert(node->right, fname, lname);   
    
        /* return the (unchanged) node pointer */
        return node;
    }
    
    // C function to search a given key in a given BST
    FriendNode* search(FriendNode* root, string fname, string lname)
    {
          FriendNode* n = new FriendNode();
              n->fname = fname;
              n->lname = lname;
              n->left = NULL;
              n->right = NULL;
              
        // Base Cases: root is null or key is present at root
        if (root == NULL || root->isEqual(*n))
            return root;
        
        // Key is greater than root's key
        if (root->lessThan(*n))
        return search(root->right, fname, lname);
    
        // Key is smaller than root's key
        return search(root->left, fname, lname);
    }
    
    void inorder(FriendNode* root)
    {
        if (root != NULL)
        {
            inorder(root->left);
            std::cout << root->fname << " " << root->lname << "\n";
            inorder(root->right);
        }
    }
};