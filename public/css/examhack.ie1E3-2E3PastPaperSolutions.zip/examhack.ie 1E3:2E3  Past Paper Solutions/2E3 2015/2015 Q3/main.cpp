#include <iostream>
#include <string>
#include <cstring>
#include "FriendTree.h"
using namespace std;

int main(int argc, char **argv)
{

    FriendTree ft;
    ft.root = ft.insert(ft.root, "A", "A");
    ft.insert(ft.root, "A", "B");
    ft.insert(ft.root, "A", "C");
    ft.insert(ft.root, "B", "C");
    
    ft.search(ft.root, "A", "A");
    
    ft.inorder(ft.root);
	return 0;
}
