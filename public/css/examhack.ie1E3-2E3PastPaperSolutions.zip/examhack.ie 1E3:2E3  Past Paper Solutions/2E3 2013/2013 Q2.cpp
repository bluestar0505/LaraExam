#define NULL 0

class ShoppingPrices {
public:
  ShoppingPrices() : prices(NULL), productIDs(NULL), productsCount(0) {}

  ShoppingPrices(double* _prices, int* _productIDs, unsigned int _productsCount)
      : prices(NULL), productIDs(NULL), productsCount(0) {
    init(_prices, _productIDs, _productsCount);
  }

  ShoppingPrices(const ShoppingPrices& other)
      : prices(NULL), productIDs(NULL), productsCount(0) {
    (*this) = other;
  }

  ~ShoppingPrices() {
    clear();
  }

  void operator=(const ShoppingPrices& rhs) {
    init(rhs.prices, rhs.productIDs, rhs.productsCount);
  }

  double basketTotal() const {
    double total = 0;
    for(unsigned int i = 0; i < productsCount; ++i) {
      total += prices[i];
    }
    return total;
  }

  double* prices;
  int* productIDs;

private:
  void clear(bool force=false) {
    if (prices != NULL) {
      delete[] prices;
      prices = NULL;
    }
    if (productIDs != NULL) {
      delete[] productIDs;
      productIDs = NULL;
    }
    productsCount = 0;
  }

  template <class T>
  T* copy(const T* src, unsigned int count) {
    if ((src == NULL) || (count == 0)) {
      if ((src == NULL) != (count == 0)) {
        throw "Logical Error";
      }
      return NULL;
    }
    T* dest = new T[count];
    for(unsigned int i = 0; i < count; ++i) {
      dest[i] = src[i];
    }
    return dest;
  }

  void init(double* _prices, int* _productIDs, unsigned int _productsCount) {
    clear();
    productsCount = _productsCount;
    prices = copy(_prices, _productsCount);
    productIDs = copy(_productIDs, _productsCount);
  }


  unsigned int productsCount;
};

//
// Testing stuff
//

#define TEST(expression)                                           \
  /* To check we've no side effects, run each test twice */        \
  for (unsigned int i = 0; i < 2; ++i) {                           \
    bool result = (expression);                                    \
    if (!result) throw "Test failed.";                             \
  }

template <class T, unsigned int N>
T sumArray(T (&array)[N]) {
  T total = 0;
  for(unsigned int i = 0; i < N; ++i) {
    total += array[i];
  }
  return total;
}

int main() {
  /* Test empty ShoppingPrices */ {
    ShoppingPrices empty;
    TEST(empty.prices == NULL);
    TEST(empty.productIDs == NULL);
    TEST(empty.basketTotal() == 0);

    /* Here destruction'll be tested */
  }

  /* Test empty ShoppingPrices assignment */ {
    ShoppingPrices empty;
    ShoppingPrices empty2;
    empty = empty2;

    TEST(empty.prices == NULL);
    TEST(empty.productIDs == NULL);
    TEST(empty.basketTotal() == 0);

    TEST(empty2.prices == NULL);
    TEST(empty2.productIDs == NULL);
    TEST(empty2.basketTotal() == 0);

    /* Here destruction'll be tested */
  }

  /* Test empty ShoppingPrices copy */ {
    ShoppingPrices empty;
    ShoppingPrices copy(empty);

    TEST(empty.prices == NULL);
    TEST(empty.productIDs == NULL);
    TEST(empty.basketTotal() == 0);

    TEST(copy.prices == NULL);
    TEST(copy.productIDs == NULL);
    TEST(copy.basketTotal() == 0);

    /* Here destruction'll be tested */
  }

  /* Test non-empty ShoppingPrices */ {
    const unsigned int count = 3;
    double prices[count] = {0.5, 0.3, 23.2};
    int IDs[count] = {1, 2, 5};

    ShoppingPrices nonEmpty(prices, IDs, count);

    TEST(nonEmpty.prices != NULL);
    TEST(nonEmpty.productIDs != NULL);
    TEST(nonEmpty.basketTotal() == sumArray(prices));

    /* Here destruction'll be tested */
  }

  /* Test non-empty to empty ShoppingPrices assignment */ {
    const unsigned int count = 3;
    double prices[count] = {0.5, 0.3, 23.2};
    int IDs[count] = {1, 2, 5};

    ShoppingPrices nonEmpty(prices, IDs, count);
    ShoppingPrices empty;
    empty = nonEmpty;

    TEST(nonEmpty.prices != NULL);
    TEST(nonEmpty.productIDs != NULL);
    TEST(nonEmpty.basketTotal() == sumArray(prices));

    TEST(empty.prices != NULL);
    TEST(empty.productIDs != NULL);
    TEST(empty.basketTotal() == sumArray(prices));

    /* Here destruction'll be tested */
  }

  /* Test empty to non-empty ShoppingPrices assignment */ {
    ShoppingPrices empty;

    const unsigned int count = 3;
    double prices[count] = {0.5, 0.3, 23.2};
    int IDs[count] = {1, 2, 5};

    ShoppingPrices nonEmpty(prices, IDs, count);
    nonEmpty = empty;

    TEST(empty.prices == NULL);
    TEST(empty.productIDs == NULL);
    TEST(empty.basketTotal() == 0);

    TEST(nonEmpty.prices == NULL);
    TEST(nonEmpty.productIDs == NULL);
    TEST(nonEmpty.basketTotal() == 0);

    /* Here destruction'll be tested */
  }

  /* Test non-empty to non-empty ShoppingPrices assignment */ {
    const unsigned int count = 3;
    double prices[count] = {0.5, 0.3, 23.2};
    int IDs[count] = {1, 2, 5};

    const unsigned int count2 = 4;
    double prices2[count2] = {0.5, 0.3, 23.2, 32.3};
    int IDs2[count2] = {1, 2, 5, 7};

    ShoppingPrices nonEmpty(prices, IDs, count);
    ShoppingPrices nonEmpty2(prices2, IDs2, count2);
    nonEmpty2 = nonEmpty;

    TEST(nonEmpty.prices != NULL);
    TEST(nonEmpty.productIDs != NULL);
    TEST(nonEmpty.basketTotal() == sumArray(prices));

    TEST(nonEmpty2.prices != NULL);
    TEST(nonEmpty2.productIDs != NULL);
    TEST(nonEmpty2.basketTotal() == sumArray(prices));

    TEST(nonEmpty.prices != nonEmpty2.prices);
    TEST(nonEmpty.productIDs != nonEmpty2.productIDs);

    /* Here destruction'll be tested */
  }

  /* Test non-empty ShoppingPrices copy */ {
    const unsigned int count = 3;
    double prices[count] = {0.5, 0.3, 23.2};
    int IDs[count] = {1, 2, 5};

    ShoppingPrices nonEmpty(prices, IDs, count);
    ShoppingPrices copy(nonEmpty);

    TEST(nonEmpty.prices != NULL);
    TEST(nonEmpty.productIDs != NULL);
    TEST(nonEmpty.basketTotal() == sumArray(prices));

    TEST(copy.prices != NULL);
    TEST(copy.productIDs != NULL);
    TEST(copy.basketTotal() == sumArray(prices));

    TEST(nonEmpty.prices != copy.prices);
    TEST(nonEmpty.productIDs != copy.productIDs);

    /* Here destruction'll be tested */
  }

  return 0;
}
