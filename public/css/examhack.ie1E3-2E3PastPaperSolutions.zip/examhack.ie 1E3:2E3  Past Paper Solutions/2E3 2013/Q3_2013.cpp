#include <string>
#include <iostream>

class Student {
public:
  std::string firstName;
  std::string lastName;
  int ID;
  Student* left;
  Student* right;
};

class StudentInfoSystem {
public:
  StudentInfoSystem() : _pRoot(NULL), _count(0) {}

  ~StudentInfoSystem() {
    removeNode(_pRoot);
  }

  // Return true if student was successfully added, otherwise return false
  bool addStudent(const std::string& firstName, const std::string& lastName,
                  const int ID) {
    Student*& pStudent = search(ID, _pRoot);
    if (pStudent != NULL) {
      return false;
    } else {
      pStudent = new Student;
      pStudent->firstName = firstName;
      pStudent->lastName = lastName;
      pStudent->ID = ID;
      pStudent->left = NULL;
      pStudent->right = NULL;

      _count += 1;
      return true;
    }
  }

  // Return true if student with such ID found, otherwise return false
  bool printStudentInfo(const int ID) {
    Student* pStudent = search(ID, _pRoot);
    if (pStudent != NULL) {
      std::cout << std::string(80, '-') << std::endl
                << pStudent->firstName << std::endl
                << pStudent->lastName << std::endl
                << pStudent->ID << std::endl;
      return true;
    } else {
      std::cout << "Student not found." << std::endl;
      return false;
    }
  }

  unsigned int numberOfStudents() const {
    return _count;
  }

private:
  void removeNode(Student*& pNode) {
    if (pNode == NULL) {
      return;
    }
    removeNode(pNode->left);
    removeNode(pNode->right);
    delete pNode;
    pNode = NULL;
  }

  Student*& search(const int ID, Student*& pNode) {
    if ((pNode == NULL) || (ID == pNode->ID)){
      return pNode;
    } else if (ID > pNode->ID) {
      return search(ID, pNode->right);
    } else {
      return search(ID, pNode->left);
    }
  }

  Student* _pRoot;
  unsigned int _count;
};

//
// Testing stuff
//

#define TEST(expression)                                           \
  /* To check we've no side effects, run each test twice */        \
  for (unsigned int i = 0; i < 2; ++i) {                           \
    bool result = (expression);                                    \
    if (!result) throw "Test failed.";                             \
  }

#define TEST2(expression)                                          \
    if (!(expression)) throw "Test failed.";

int main() {
  /* Empty info system test */ {
    const int randomID = 10;

    StudentInfoSystem infoSystem;
    TEST(infoSystem.numberOfStudents() == 0);
    TEST(infoSystem.printStudentInfo(randomID) == false);
  }

  /* One student info system test */ {
    const int randomID = 10;

    StudentInfoSystem infoSystem;
    TEST2(infoSystem.addStudent("John", "Doh", 32) == true);
    TEST(infoSystem.numberOfStudents() == 1);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(32) == true);

    TEST2(infoSystem.addStudent("John", "Doh", 32) == false);
    TEST(infoSystem.numberOfStudents() == 1);
    TEST(infoSystem.printStudentInfo(32) == true);

    TEST2(infoSystem.addStudent("James", "Potter", 32) == false);
    TEST(infoSystem.numberOfStudents() == 1);
    TEST(infoSystem.printStudentInfo(32) == true);
  }

  /* Growing up IDs info system test */ {
    const int randomID = 10;

    StudentInfoSystem infoSystem;
    TEST2(infoSystem.addStudent("John", "Doh", 32) == true);
    TEST(infoSystem.numberOfStudents() == 1);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(32) == true);

    infoSystem.addStudent("Charles", "Pearson", 150);
    TEST(infoSystem.numberOfStudents() == 2);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(32) == true);
    TEST(infoSystem.printStudentInfo(150) == true);

    infoSystem.addStudent("Michel", "St James", 322);
    TEST(infoSystem.numberOfStudents() == 3);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(32) == true);
    TEST(infoSystem.printStudentInfo(150) == true);
    TEST(infoSystem.printStudentInfo(322) == true);
  }

  /* Growing down IDs info system test */ {
    const int randomID = 10;

    StudentInfoSystem infoSystem;
    infoSystem.addStudent("Michel", "St James", 322);
    TEST(infoSystem.numberOfStudents() == 1);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(322) == true);

    infoSystem.addStudent("Charles", "Pearson", 150);
    TEST(infoSystem.numberOfStudents() == 2);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(150) == true);
    TEST(infoSystem.printStudentInfo(322) == true);

    TEST2(infoSystem.addStudent("John", "Doh", 32) == true);
    TEST(infoSystem.numberOfStudents() == 3);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(322) == true);
    TEST(infoSystem.printStudentInfo(150) == true);
    TEST(infoSystem.printStudentInfo(32) == true);
  }

  /* Mixed growing IDs info system test */ {
    const int randomID = 10;

    StudentInfoSystem infoSystem;
    infoSystem.addStudent("Charles", "Pearson", 150);
    TEST(infoSystem.numberOfStudents() == 1);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(150) == true);

    infoSystem.addStudent("Michel", "St James", 322);
    TEST(infoSystem.numberOfStudents() == 2);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(150) == true);
    TEST(infoSystem.printStudentInfo(322) == true);

    TEST2(infoSystem.addStudent("John", "Doh", 32) == true);
    TEST(infoSystem.numberOfStudents() == 3);
    TEST(infoSystem.printStudentInfo(randomID) == false);
    TEST(infoSystem.printStudentInfo(322) == true);
    TEST(infoSystem.printStudentInfo(150) == true);
    TEST(infoSystem.printStudentInfo(32) == true);
  }

  return 0;
}
