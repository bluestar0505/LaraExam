#include <string>
#include <iostream>

class SongNode {
public:
  int duration;
  std::string songName;
  std::string artist;
  SongNode* next;
};

class MusicCollection {
public:
  MusicCollection() : head(NULL) {}

  ~MusicCollection() {
    SongNode* pNode = head;
    while(pNode != NULL) {
      removeNode(pNode);
    }
  }

  void addSong(const std::string& songName, const std::string& artist,
               int duration) {
    SongNode*& pNode = search(songName, artist);
    if ((pNode != NULL) && ((pNode->artist.compare(artist) == 0) &&
                            (pNode->songName.compare(songName) == 0))) {
      throw "Song already in collection!";
    }

    SongNode* pNewNode = new SongNode;
    pNewNode->artist = artist;
    pNewNode->songName = songName;
    pNewNode->duration = duration;
    pNewNode->next = pNode;
    pNode = pNewNode;
  }

  void removeSong(const std::string& songName, const std::string& artist) {
    SongNode*& pNode = search(songName, artist);
    if ((pNode == NULL) || ((pNode->artist.compare(artist) != 0) &&
                            (pNode->songName.compare(songName) != 0))) {
      throw "Removing song not found!";
    }

    removeNode(pNode);
  }

  double getLongest() const {
    const SongNode* pNode = head;
    const SongNode* pLongest = head;
    while(pNode != NULL) {
      // first longest song'll be returned
      if (pLongest->duration < pNode->duration) {
        pLongest = pNode;
      }
      pNode = pNode->next;
    }
    if (pLongest == NULL) {
      throw "No songs in collection";
    }
    return pLongest->duration;
  }

  void print() {
    const SongNode* pNode = head;
    std::cout << std::string(80, '-') << std::endl;
    while(pNode != NULL) {
      std::cout << "Artist: " << pNode->artist
                << "; Song Name: " << pNode->songName
                << "; Duration: " << pNode->duration << std::endl;
      pNode = pNode->next;
    }
  }

private:
  void removeNode(SongNode*& pNode) {
    SongNode* pTemp = pNode;
    pNode = pNode->next;
    delete pTemp;
    pTemp = NULL;
  }

  // Return song by criteria, or first song next by criteria.
  SongNode*& search(const std::string& songName, const std::string& artist) {
    SongNode** ppNode = &head;
    while(*ppNode != NULL) {
      SongNode*& pNode = *ppNode;
      int artistCmp = pNode->artist.compare(artist);
      if ((artistCmp > 0) ||
          ((artistCmp == 0) && (pNode->songName.compare(songName) >= 0))) {
        return pNode;
      }
      ppNode = &(pNode->next);
    }
    return *ppNode;
  }

  SongNode* head;
};

#define TEST_EXCEPT(expression, expected_result) \
                                                 \
{                                                \
    bool result = false;                         \
    try {                                        \
      (expression);                              \
    } catch (const char* msg) {                  \
      result = true;                             \
    }                                            \
    if (result != expected_result) {             \
      throw "Test failed.";                      \
    }                                            \
}

#define TEST(expression)                                           \
  /* To check we've no side effects, run each test twice */        \
  for (unsigned int i = 0; i < 2; ++i) {                           \
    bool result = (expression);                                    \
    if (!result) throw "Test failed.";                             \
  }

int main() {
  /* Test empty collection */ {
    MusicCollection collection;
    collection.print();
    TEST_EXCEPT(collection.getLongest(), true);
    TEST_EXCEPT(collection.removeSong("some", "name"), true);
  }

  /* Test one item collection */ {
    MusicCollection collection;
    collection.addSong("some", "name", 11);
    collection.print();
    TEST(collection.getLongest() == 11);
    TEST_EXCEPT(collection.removeSong("some", "name"), false);
    TEST_EXCEPT(collection.removeSong("some", "name"), true);
  }

  /* Test multiple items collection */ {
    MusicCollection collection;
    collection.addSong("some", "name", 11);
    TEST_EXCEPT(collection.addSong("some", "name", 11), true);
    TEST_EXCEPT(collection.addSong("some", "name", 12), true);
    collection.addSong("some1", "name", 11);
    collection.print();

    collection.addSong("some1", "name2", 11);
    collection.print();

    collection.addSong("some", "naaa", 11);
    collection.print();

    collection.addSong("some1", "naaaa", 12);
    collection.print();

    TEST(collection.getLongest() == 12);
    TEST_EXCEPT(collection.removeSong("some", "naaa"), false);
  }

  return 0;
}
