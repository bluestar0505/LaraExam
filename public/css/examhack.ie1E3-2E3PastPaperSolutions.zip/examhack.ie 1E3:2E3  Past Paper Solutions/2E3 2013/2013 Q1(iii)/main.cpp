#include <iostream>
using namespace std;


int checkBit(int x, int y)
{
    return ((x & (1 << y)) != 0);
}

int main(int argc, char **argv)
{
	cout << checkBit(43, 2);
	return 0;
}
