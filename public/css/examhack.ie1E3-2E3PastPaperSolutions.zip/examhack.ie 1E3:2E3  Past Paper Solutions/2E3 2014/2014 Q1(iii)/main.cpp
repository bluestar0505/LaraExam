#include <iostream>
using namespace std;


int setBit(int x, int y)
{
    x |= 1 << y;
    return x;
}


int main(int argc, char **argv)
{
	cout << setBit(42, 2);
	return 0;
}
