#include "Student.h"
class Module
{
    public : Student* root;
    
    public: Module()
    {
        root = NULL;
    }
    
    bool AddStudent(Student* key) {
       root = insertRec(root, key);
       return true;
    }
     
    /* A recursive function to insert a new key in BST */
    Student* insertRec(Student* root, Student* key) {
 
        /* If the tree is empty, return a new node */
        if (root == NULL) {
            root = key;
            return root;
        }
 
        /* Otherwise, recur down the tree */
        if (key->id < root->id)
            root->left = insertRec(root->left, key);
        else if (key->id > root->id)
            root->right = insertRec(root->right, key);
 
        /* return the (unchanged) node pointer */
        return root;
    }
    
    
     bool AddMarkForStudent(int id, double marks)
     {
         return AddMarkForStudent(root, id, marks);
     }
    
    // C function to search a given key in a given BST
    bool AddMarkForStudent(Student* root, int id, double m)
    {
          Student* n = new Student();
            
              n->id = id;
              n->left = NULL;
              n->right = NULL;
              
        // Base Cases: root is null or key is present at root
        if (root == NULL)
            return false;
            
        if (root->id == n->id)
        {
            root->mark = m;
            return true;
        }
        
        // Key is greater than root's key
        if (root->id < n->id)
        return AddMarkForStudent(root->right, id, m);
    
        // Key is smaller than root's key
        return AddMarkForStudent(root->left, id, m);
    }
    
    void ListStudentsAndMarks()
    {
        inorder(root);
    }
    
    double GetHighestMark()
    {
        double high = 0;
        inorder(root, &high);
        return high;
    }
    
    void inorder(Student* root, double* max)
    {
        if (root != NULL)
        {
            inorder(root->left, max);
            if (*max < root->mark)
            {
                *max = root->mark;
            }
            
            inorder(root->right, max);
        }
    }
    
    
    void inorder(Student* root)
    {
        if (root != NULL)
        {
            inorder(root->left);
            std::cout << root->id << " "<<root->fname << " " << root->lname << " " <<root->mark <<  "\n";
            inorder(root->right);
        }
    }
};