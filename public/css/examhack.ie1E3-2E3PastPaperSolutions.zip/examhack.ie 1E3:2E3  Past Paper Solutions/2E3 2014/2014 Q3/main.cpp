#include <iostream>
#include <string>
#include <cstring>
#include "Module.h"
using namespace std;


int main(int argc, char **argv)
{

   Module tree;
   Student s;
   s.id = 1;
   s.fname = "A";
   s.lname = "B";
   s.mark = 10;
   s.left = NULL;
   s.right = NULL;
   
  tree.AddStudent(&s);
   
   Student s1;
   s1.id = 2;
   s1.fname = "B";
   s1.lname = "C";
   s1.mark = 100;
   s1.left = NULL;
   s1.right = NULL;
   
   
   tree.AddStudent(&s1);
   tree.AddMarkForStudent(1, 60);
   cout << "Highest mark " << tree.GetHighestMark() << "\n";
   
   tree.ListStudentsAndMarks();
        
	return 0;
}
