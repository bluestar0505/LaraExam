#include <string>
using namespace std;

class Student
{
public:
    
    string fname;
    string lname;
    int id;
    double mark;
    Student* left;
    Student* right;
    

};