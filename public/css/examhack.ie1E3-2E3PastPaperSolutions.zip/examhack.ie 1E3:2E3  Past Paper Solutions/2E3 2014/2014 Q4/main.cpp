#include <iostream>
#include <string>
#include "LinkedList.h"
using namespace std;

int main()
{
    
    LinkedList l;
    
    l.add(10);
    l.add(20);
    l.add(30);
    
    cout << "Max " << l.getN() << "\n";
    
    l.remove(30);
    cout << "Max " << l.getN() << "\n";
    
    l.print();
    
    return 0;
}