#include <iostream>
#include <string>
using namespace std;

class LinkedList{
    // Struct inside the class LinkedList
    // This is one node which is not needed by the caller. It is just
    // for internal work.
    struct Node {
        double x;
        Node *next;
    };

// public member
public:
    // constructor
    LinkedList(){
        head = NULL; // set head to NULL
    }

    // This prepends a new value at the beginning of the list
    bool add(double val){
        Node *n = new Node();   // create new Node
        n->x = val;             // set value
        n->next = head;         // make the node point to the next node.
                                //  If the list is empty, this is NULL, so the end of the list --> OK
        head = n;               // last but not least, make the head point at the new node.
        return true;
    }

    bool remove(double value)
    {
           // Store head node
        Node* temp = head;
        Node* prev = NULL;
     
        // If head node itself holds the value to be deleted
        if (temp != NULL && temp->x == value)
        {
            head = temp->next;   // Changed head
            delete temp;               // free old head
            return true;
        }
     
        // Search for the value to be deleted, keep track of the
        // previous node as we need to change 'prev->next'
        while (temp != NULL && temp->x != value)
        {
            prev = temp;
            temp = temp->next;
        }
     
        // If value was not present in linked list
        if (temp == NULL) return false;
     
        // Unlink the node from linked list
        prev->next = temp->next;
     
        delete temp;  // Free memory
        return true;
    }
    
    int getN()
    {
        int count = 0;
        
        Node* temp = head;
        
        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }
        
        return count;
    }
    
    void print()
    {
        
        Node* temp = head;
        
        while (temp != NULL)
        {
            cout << temp->x << "\n";
            temp = temp->next;
        }                

    }

// private member
private:
    Node *head; // this is the private member variable. It is just a pointer to the first Node
};